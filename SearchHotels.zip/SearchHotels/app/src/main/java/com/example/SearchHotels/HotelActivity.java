package com.example.SearchHotels;

import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class HotelActivity extends AppCompatActivity {

    ArrayList<Hotel> hotelArrayList;
    HotelAdapter adapter;

    Hotel[] hotels = new Hotel[]{
            new Hotel("Ибис баджет Москва Панфиловская",
                    "Первый в России отель две звезды под управлением ACCOR Hotels. Oтель ibis budget расположен в центре Москвы в шаговой доступности от МЦК Панфиловская и Метро, в 15 минутах езды от центра Москвы. Сладкий сон в тепле: номера на 1-3 человек! Пойте в просторном душе и найдите канал по вкусу, включив телевизор с плоским экраном! В ibis budget новые кровати с пышными подушками и мягчайшими матрасами.",
                    "Бесплатный WiFi\n" +
                            "Ресторан\n" +
                            "Бизнес-центр с Wi-Fi\n" +
                            "Возможен завтрак\n" +
                            "Многоязычный персонал\n" +
                            "Отель для некурящих\n" +
                            "Пандусы для кресел-каталок\n" +
                            "Питомцы разрешены",
                    108,
                    "https://s-ec.bstatic.com/images/hotel/max1024x768/105/105205064.jpg"
            ),


            new Hotel("AZIMUT Отель Тульская Москва",
                    "AZIMUT Отель Тульская Москва 4* – современный стильный отель, расположенный в 10 минутах ходьбы от станции метро Тульская, в историческом здании 1867 года в лофт-квартале «Даниловская мануфактура». AZIMUT Отель Тульская Москва располагается в деловой зоне города. Неподалеку от него находятся Донской монастырь, старое здание Третьяковской галереи, Новодевичий монастырь и Новодевичье кладбище. Всего четыре остановки на метро позволяют гостям AZIMUT Отель Тульская Москва оказаться в самом сердце столицы – на Красной площади. За 3 станции по МЦК вы можете добраться до стадиона «Лужники». Станция МЦК «Верхние котлы» находится в 7 минутах ходьбы.",
                    "Первый канал\n" +
                            "Бесплатный WiFi\n" +
                            "Бесплатная парковка\n" +
                            "Ресторан\n" +
                            "Бар/лобби\n" +
                            "Обслуживание номеров\n" +
                            "Бизнес-центр с Wi-Fi\n" +
                            "Консьерж",
                    2005,
                    "https://s-ec.bstatic.com/images/hotel/max1024x768/739/73922290.jpg"
            ),

            new Hotel("Вега Измайлово Отель и Конгресс-Центр",
                    "Отель с 2 ресторанами и фитнес-центром расположен в Москве, рядом с Измайловским парком, в 3 минутах ходьбы от станций метро «Партизанская» и станции МЦК «Измайлово». На территории действует бесплатный Wi-Fi. Номера отеля «Гостиница Вега Измайлово» оснащены кондиционером и телевизором с плоским экраном и спутниковыми каналами. В ванной комнате предоставляются фен, халаты, тапочки и бесплатные туалетно-косметические принадлежности. Из окон всех номеров открывается живописный вид на комплекс «Кремль в Измайлово» или Измайловский парк. В ресторанах отеля «Гостиница Вега Измайлово» подают блюда интернациональной и местной кухни. Гости могут заказать легкие закуски в кафе и напитки в баре. От станции метро «Партизанская» можно без пересадок доехать до центра Москвы и Красной площади за 15 минут. Международные аэропорты Домодедово и Шереметьево находятся в 1 часе езды. Официальное время заезда: 14:00 Официально время выезда: 12:00",
                    "Кондиционер\n" +
                            "Холодильник в комнате\n" +
                            "Номера для людей с ограниченными возможностями\n" +
                            "Номера для некурящих\n" +
                            "Номера-люкс\n" +
                            "Семейные номера",
                    2982,
                    "https://russia-in-us.com/wp-content/uploads/2017/06/fasad6.jpg"
            ),

            new Hotel("Хостел Гудмуд",
                    "GoodMood Hostel расположен в историческом центре Москвы, всего в двух минутах ходьбы от станции метро Китай-Город и в 15 минутах от Кремля. Стойка ресепшн хостела работает 24 часа, заезд возможен в любое время суток. Мы предлагаем нашим гостям персональные локеры, а также комнату для хранения багажа. Гостям предлагаются следующие варианты размещения: отдельные номера или места в общей комнате. Три санузла и три душевые общие для всех жилых комнат и расположены на этаже. Современная просторная кухня оснащена всем необходимым для приготовления любимых блюд. Кофе и чай для наших гостей бесплатные. В вашем распоряжении также уютная гостиная и мини-библиотека. Постельное белье и полотенца выдаются бесплатно на весь период проживания. Неподалеку от нас Вы найдете множество кафе, баров и ресторанов.",
                    "Бесплатный WiFi\n" +
                            "Маршрутный автобус\n" +
                            "Многоязычный персонал\n" +
                            "Отель для некурящих\n" +
                            "Прачечная\n" +
                            "Прачечная с самообслуживанием\n" +
                            "WiFi в общественных местах",
                    108,
                    "https://s-ec.bstatic.com/images/hotel/max1024x768/856/85608069.jpg"
            ),

            new Hotel("AZIMUT Отель Смоленская Москва",
                    "AZIMUT Отель Смоленская Москва – это новый 4-звёздочный 23-этажный отель в центре Москвы. Интерьер гостиницы сочетает в себе современные технологии и дизайнерские находки для максимального удобства жилого и рабочего пространств.",
                    "Обслуживание номеров\n" +
                            "Ресторан\n" +
                            "Бар/лобби\n" +
                            "Бесплатный WiFi\n" +
                            "Бизнес-центр с Wi-Fi\n" +
                            "Возможен завтрак\n" +
                            "Консьерж\n" +
                            "Конференц-залы",
                    1022,
                    "https://i.archi.ru/i/650/260238.jpg"
            ),
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hotel_list_view);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null){
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setDisplayUseLogoEnabled(true);
            actionBar.setIcon(R.drawable.ic_action_logo);
            actionBar.setTitle("    " + actionBar.getTitle());
        }


       hotelArrayList = new ArrayList<>(Arrays.asList(hotels));
       adapter = new HotelAdapter(this, hotelArrayList);

        ListView hotelListView = (ListView) findViewById(R.id.hotelListView);
        hotelListView.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu, menu);

        MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Log.d("SEARCH", newText);

                hotelArrayList.clear();

                if (newText.equals("")) {
                    hotelArrayList.addAll(Arrays.asList(hotels));
                } else {
                    for (Hotel hotel : hotels  ) {
                        if (hotel.getName().toLowerCase().contains(newText.toLowerCase())) {
                            hotelArrayList.add(hotel);
                        }
                    }
                }

                adapter.notifyDataSetChanged();

                return false;
            }
        });


        return super.onCreateOptionsMenu(menu);
    }
}
