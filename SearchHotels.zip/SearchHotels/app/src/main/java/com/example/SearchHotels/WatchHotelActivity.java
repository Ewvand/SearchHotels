package com.example.SearchHotels;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class WatchHotelActivity extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Внешний вид интерфейса
        setContentView(R.layout.watch_hotel);
        //Размещение элементов

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        //Получение данных
        String name = intent.getStringExtra("name");
        String description = intent.getStringExtra("description");
        String services = intent.getStringExtra("services");
        int numbersofReviews = intent.getIntExtra("numbersofReviews", 0);
        String image = intent.getStringExtra("image");

        if (actionBar != null) {
            actionBar.setTitle(name);
        }


        TextView nameTextView = (TextView) findViewById(R.id.nameTextView);
        TextView descriptionTextView = (TextView) findViewById(R.id.descriptionTextView);
        TextView servicesTextView = (TextView) findViewById(R.id.servicesTextView);
        TextView numbersofReviewsTextView = (TextView) findViewById(R.id.numbersofReviewsTextView);
        ImageView imageView = (ImageView) findViewById(R.id.hotelImage);

        nameTextView.setText(name);
        descriptionTextView.setText(description);
        servicesTextView.setText(services);
        numbersofReviewsTextView.setText(numbersofReviews + "reviews");
        Picasso.get().load(image).into(imageView);
    }
}


