package com.example.SearchHotels;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;

//Класс для упрощения связывания данных с элементов управления
class HotelAdapter extends BaseAdapter {
    private Activity activity;
    private ArrayList<Hotel> hotelArrayList;
    private LayoutInflater inflater;

    HotelAdapter(Activity activity, ArrayList<Hotel> hotelArrayList) {
        this.activity = activity;
        this.hotelArrayList = hotelArrayList;
    }


    @Override
    public int getCount() {
        return this.hotelArrayList.size();
    }

    @Override
    public Hotel getItem(int position) {
        return this.hotelArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (inflater == null)
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertView == null)
            convertView = inflater.inflate(R.layout.hotel_list_item,null);

        TextView name = (TextView) convertView.findViewById(R.id.nameTextView);
        TextView description = (TextView) convertView.findViewById(R.id.descriptionTextView);
        TextView services = (TextView) convertView.findViewById(R.id.servicesTextView);
        TextView numbersofReviews = (TextView) convertView.findViewById(R.id.numberOfeviewsTextView);
        ImageView image = (ImageView) convertView.findViewById(R.id.imageView);

        final Hotel hotel = getItem(position);
        name.setText(hotel.getName());
        if (hotel.getDescription().length() <= 70) {
            description.setText((hotel.getDescription()));
        }  else {
            description.setText(hotel.getDescription().substring(0, 70) + "...");
        }

        services.setText(hotel.getServices());
        numbersofReviews.setText(hotel.getNumersofReviews() + " отзывы");

        Picasso.get().load(hotel.getImage()).into(image);

        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, WatchHotelActivity.class);
                intent.putExtra("name", hotel.getName());
                intent.putExtra("description", hotel.getDescription());
                intent.putExtra("services", hotel.getServices());
                intent.putExtra("numbersofReviews", hotel.getNumersofReviews());
                intent.putExtra("image", hotel.getImage());

                activity.startActivity(intent);
            }
        });

        return convertView;
    }
}
