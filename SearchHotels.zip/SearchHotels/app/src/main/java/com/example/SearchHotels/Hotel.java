package com.example.SearchHotels;

//Класс записи и вывода данных
class Hotel {
    private String name, description, services, image;
    private int numbersofReviews;

    Hotel(String name, String description, String services, int numbersofReviews, String image) {
        super();
        this.name = name;
        this.description = description;
        this.services = services;
        this.numbersofReviews = numbersofReviews;
        this.image = image;
    }

    String getName() {
        return this.name;
    }
    String getDescription() {
        return this.description;
    }
    String getServices() {
        return this.services;
    }
    int getNumersofReviews() {
        return this.numbersofReviews;
    }
    String getImage(){
        return this.image;
    }
}
